<?php

$dowhatarray = array();
$dowhatarray[] = "để đi xem phim với bạn";
$dowhatarray[] = "để ăn tối với bạn";
$dowhatarray[] = "để tán gẫu với bạn";
$dowhatarray[] = "để hẹn hò với bạn";
$dowhatarray[] = "cho hôn nhân của bạn";
$dowhatarray[] = "để yêu bạn";
$dowhatarray[] = "để bạn có thể yêu";
$dowhatarray[] = "để bạn có đặt niềm tin";

$imgarray = array();
$imgarray[] = "0.jpg";
$imgarray[] = "1.jpg";
$imgarray[] = "2.jpg";

$imgstore = "../user_images";
$realimg_path = "http://apps.kimnguu.org/nguoitinhvalentine/examples";

require '../src/facebook.php';

$action = (@$_REQUEST["action"]) ? $_REQUEST["action"] : "";

$facebook = new Facebook(array(
  'appId'  => '230122810412051',
  'secret' => '3c5453ab3e4133c25913a9b5f07f5bb9',
));

// See if there is a user from a cookie
$user = $facebook->getUser();

if ($user) {
  try {
    // Proceed knowing you have a logged in user who's authenticated.
    $user_profile = $facebook->api('/me');
  } catch (FacebookApiException $e) {
    echo '<pre>'.htmlspecialchars(print_r($e, true)).'</pre>';
    $user = null;
  }
}
if ($action=='getthebest') {
if ($user) {
getthebest();
} else {
    	$login_url = $facebook->getLoginUrl(array('scope' => 'user_birthday,user_likes,user_relationships,user_relationship_details,user_photos,user_videos,friends_birthday,friends_likes,friends_relationships,friends_relationship_details,friends_photos,publish_actions,publish_stream,read_stream,status_update,photo_upload,video_upload,read_friendlists'));
    	?>
		<a class="fb_button fb_button_large" href="<?php echo $login_url; ?>">
			<span class="fb_button_text">Đăng nhập để sử dụng ứng dụng</span>
		</a>
		<?php
}

} else {
?>
<!DOCTYPE html>
<html xmlns:fb="http://www.facebook.com/2008/fbml">
  <body style="text-align:center;">
    <?php if ($user) { ?>
		<a class="fb_button fb_button_large" href="#">
			<span class="fb_button_text">Click vào đây để xem kết quả</span>
		</a>
    <?php } else { ?>
    	<?php $login_url = $facebook->getLoginUrl(array('scope' => 'user_birthday,user_likes,user_relationships,user_relationship_details,user_photos,user_videos,friends_birthday,friends_likes,friends_relationships,friends_relationship_details,friends_photos,publish_actions,publish_stream,read_stream,status_update,photo_upload,video_upload,read_friendlists')); ?>
		<a class="fb_button fb_button_large" href="<?php echo $login_url; ?>">
			<span class="fb_button_text">Đăng nhập để sử dụng ứng dụng</span>
		</a>
    <?php } ?>
    <div id="fb-root"></div>
    <script>
      window.fbAsyncInit = function() {
        FB.init({
          appId: '<?php echo $facebook->getAppID() ?>',
          cookie: true,
          xfbml: true,
          oauth: true
        });
        FB.Event.subscribe('auth.login', function(response) {
          window.location.reload();
        });
        FB.Event.subscribe('auth.logout', function(response) {
          window.location.reload();
        });
      };
      (function() {
        var e = document.createElement('script'); e.async = true;
        e.src = document.location.protocol +
          '//connect.facebook.net/en_US/all.js';
        document.getElementById('fb-root').appendChild(e);
      }());
    </script>
  </body>
</html>
<?php } ?>

<?php
function getthebest() {
	global $facebook, $user_profile, $dowhatarray, $imgarray, $imgstore, $realimg_path;
	if (file_exists($imgstore)===false) {
		mkdir($imgstore, 0777);
		chmod($imgstore, 0777);
	}
	
	$imgstore = $imgstore."/".date("Y");
	if (file_exists($imgstore)===false) {
		mkdir($imgstore, 0777);
		chmod($imgstore, 0777);
	}
	
	$imgstore = $imgstore."/".date("m");
	if (file_exists($imgstore)===false) {
		mkdir($imgstore, 0777);
		chmod($imgstore, 0777);
	}
	
	$imgstore = $imgstore."/".date("d");
	if (file_exists($imgstore)===false) {
		mkdir($imgstore, 0777);
		chmod($imgstore, 0777);
	}
	$userdir = $imgstore."/".$user_profile["id"];
	if (file_exists($userdir)===false) {
		mkdir($userdir, 0777);
		chmod($userdir, 0777);
	}
	$userimage = $userdir."/".time().".jpg";
	
	$gender = rand(0,1);
	if ($user_profile["gender"]=="male") {
		$gender = "female";
	} elseif($user_profile["gender"]=="female") {
		$gender = "male";
	} else {
		$gender = ($gender==0) ? "female" : "male";
	}
	$friends = $facebook->api("/me/friends");
	$f_array = array();
	foreach ($friends["data"] as $friend) {
		$f_array[] = $friend["id"];
	}
	$friends = implode(",",$f_array);
	$friends = $facebook->api("/fql?q=select+uid,username,first_name,middle_name,last_name,name,pic_small,pic_big,pic_square,pic,profile_url+from+user+where+uid+in+(".$friends.")+and+sex='".$gender."'");
	$friendcount = count($friends["data"]);
	$friendoffset = rand(0,$friendcount-1);
	$bestfriend = $friends["data"][$friendoffset];
	
	$friend_im = imageCreateFromJpegEx($bestfriend["pic_big"]);
	$friend_im_width = imagesx($friend_im);
	$friend_im_height = imagesy($friend_im);
	
	$im = imageCreateFromJpegEx("../images/".$imgarray[rand(0,count($imgarray)-1)]);
	$text_color = imagecolorallocate($im, 255, 255, 255);
	imagettftext($im, 16, 0, 25, 20, $text_color, "../fonts/Arial Bold.ttf", 'Người phù hợp nhất');
	imagettftext($im, 16, 0, 25, 45, $text_color, "../fonts/Arial Bold.ttf", $dowhatarray[rand(0,count($dowhatarray)-1)]);
	imagettftext($im, 16, 0, 25, 85, $text_color, "../fonts/Arial.ttf", $bestfriend["name"]);
	imagecopymerge ( $im, $friend_im, 25, 100, 0, 0, $friend_im_width, $friend_im_height, 100);
	if (imagejpeg($im, $userimage, 100)) {
		echo $realimg_path . "/" . $userimage;
	} else {
		echo "Có lỗi xẩy ra! Chúng tôi sẽ xem xét và sửa chữa!";
	}
	imagedestroy($friend_im);
	imagedestroy($im);
	exit();
}

function imageCreateFromJpegEx($file)
{
    $data = file_get_contents($file);
    $im = @imagecreatefromstring($data);
    $i = 0;
    while (!$im)
    {
        $data = substr_replace($data, "", -3, -2);
        $im = @imagecreatefromstring($data);
    }
    return $im;
}
function bigintval($value) {
  $value = trim($value);
  if (ctype_digit($value)) {
    return $value;
  }
  $value = preg_replace("/[^0-9](.*)$/", '', $value);
  if (ctype_digit($value)) {
    return $value;
  }
  return 0;
}
?>