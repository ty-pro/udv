<?php
	

	
	
$dowhatarray = array();
$dowhatarray[] = "";

$imgarray = array();
$imgarray[] = "1.jpg";

$imgstore = "user_images";
$realimg_path = "http://www.xclub.vn/facebook";

$url = "https://apps.facebook.com/xclubvn/";

require 'src/facebook.php';

$action = (@$_REQUEST["action"]) ? $_REQUEST["action"] : "";

$facebook = new Facebook(array(
  'appId'  => '411661998847283',
  'secret' => '8f1825917ce5dfe9f8a03ee47d20c875',

));

// See if there is a user from a cookie
$user = $facebook->getUser();

				 
						 

if ($user) {
  try {
    // Proceed knowing you have a logged in user who's authenticated.
    $user_profile = $facebook->api('/me');
  } catch (FacebookApiException $e) {
    echo '<pre>'.htmlspecialchars(print_r($e, true)).'</pre>';
    $user = null;
  }
}
if ($action=='getthebest') {
	if ($user) {
		getthebest();
	} else {
    	$login_url = $facebook->getLoginUrl(array('scope' => 'user_birthday,user_likes,user_relationships,user_relationship_details,user_photos,user_videos,friends_birthday,friends_likes,friends_relationships,friends_relationship_details,friends_photos,publish_actions,publish_stream,read_stream,status_update,photo_upload,video_upload,read_friendlists'));
    	?>
		<a class="fb_button fb_button_large" href="<?php echo $login_url; ?>">
			<span class="fb_button_text">Đăng nhập để chơi ứng dụng</span>
		</a>
		<?php
	}
} elseif($action=="posttofacebook") {
	if ($user) {
	
	global $kq;
	$fql="SELECT uid,name,sex FROM user WHERE uid IN (SELECT uid2 FROM friend WHERE uid1=me() ORDER BY rand()) AND sex='female' LIMIT 4";
	$kq=$facebook->api( array(
							 'method' => 'fql.query',
							 'query' => $fql,
						 ));
	
		$imageurl = (@$_REQUEST["imageurl"]) ? $_REQUEST["imageurl"] : "";
		$imageurl = base64_decode($imageurl);
		$dowhat = (@$_REQUEST["dowhat"]) ? $_REQUEST["dowhat"] : "";
		$message = (@$_REQUEST["message"]) ? $_REQUEST["message"] : "";
		$taguserid = (@$_REQUEST["taguserid"]) ? $_REQUEST["taguserid"] : "";
		$taguserx = (@$_REQUEST["taguserx"]) ? $_REQUEST["taguserx"] : "";
		$tagusery = (@$_REQUEST["tagusery"]) ? $_REQUEST["tagusery"] : "";
		
		$tags = array();
		$tags[] = array('tag_uid' => $taguserid, 'x' => intval($taguserx), 'y' => intval($tagusery));
		$tags = json_encode($tags);
		
		$facebook->setFileUploadSupport(true);
		//Create an album
		$album_details = array(
        'message'=> 'Ứng dụng Mình sẽ làm được',
        'name'=> 'Ứng dụng Mình sẽ làm được'
        );
        $create_album = $facebook->api('/me/albums', 'post', $album_details);
        $album_uid = $create_album['id'];
		//Upload a photo to album of ID...
		$photo_details = array(
    		'message' => $message ."\r\n". $dowhat . "\r\nChết cười cái ứng dụng ^^ bà con Click vào link: " . $url." để xem học sinh của mình nhé B-) nhé ^^",
    		'tags' => $tags
		);
		$file=$imageurl; //lấy link file
		$photo_details['image'] = '@' . realpath($file);
		$upload_photo = $facebook->api('/'.$album_uid.'/photos', 'post', $photo_details);
		
	
		
		echo "Kết quả đã được gửi lên Facebook, cảm ơn bạn đã sử dụng ứng dụng này!";
		@unlink($imageurl);
	} else {
    	$login_url = $facebook->getLoginUrl(array('scope' => 'user_birthday,user_likes,user_relationships,user_relationship_details,user_photos,user_videos,friends_birthday,friends_likes,friends_relationships,friends_relationship_details,friends_photos,publish_actions,publish_stream,read_stream,status_update,photo_upload,video_upload,read_friendlists'));
    	?>
		<a class="fb_button fb_button_large" href="<?php echo $login_url; ?>">
			<span class="fb_button_text">Đăng nhập để sử dụng ứng dụng</span>
		</a>
		<?php
	}
} else {
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://www.facebook.com/2008/fbml"><head><title>EithreeLove <3</title><style type="text/css">
 <meta name="Author" content="Ứng dụng ">
 <meta name="Keywords" content="Ứng dụng ">
 <meta name="Description" content="Ứng dụng ">
<!--
body,td,th {
	font-family: Times New Roman, Times, serif;
}
-->
</style><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
  <body style="text-align:center;">
    <?php if ($user) { ?>
    	<div class="result_show">
    		<img src="images/blank.gif" id="result_show_img" />
    	</div>
    	<div id="loading_img" style="display:none;">
    		<img src="images/loading-long.gif" /><br />
			<img src="images/thayboi.jpg" /><br />
    		Vui lòng chờ trong giây lát, hệ thống đang xử lý!.......
    	</div>
    	<div id="button_view_result_div">
		<a id="button_view_result" class="fb_button fb_button_large" href="#" onClick="view_result();return;">
			<span class="fb_button_text">Xem kết quả</span>
		</a>
		<br />
		<br />
		</div>
		<div id="send_to_facebook" style="display:none;">
		^^ Đợi thêm chút nữa nhé! Khi nào ảnh hiện ra thì hãy: <br />Viết cảm nhận của bạn:<br />
		<input type="textbox" name="message" id="message" size="30" />
		<input id="send_image_path" type="hidden" name="imgpath" value="" />
		<input id="dowhat" type="hidden" name="do_what" value="" />
		<input id="taguserid" type="hidden" name="taguserid" value="" />
		<input id="taguserx" type="hidden" name="taguserx" value="" />
		<input id="tagusery" type="hidden" name="tagusery" value="" />
		<br />
		<a id="button_send_to_facebook" class="fb_button fb_button_large" href="#" onClick="send_to_facebook();return;">
			<span class="fb_button_text">Gửi lên Facebook</span>
		</a>
		</div>
    	<div id="post_to_facebook_wait_img" style="display:none;">
    		<br />
    		<br />
    		<img src="images/loading-long.gif" /><br />
    		Vui lòng chờ trong giây lát! Chúng tôi đang đưa kết quả của bạn lên Facebook!
    	</div>
    	<div id="button_try_again_div" style="display:none;">
		<br />
		<br />
		<a id="button_try_again" class="fb_button fb_button_large" href="#" onClick="location.reload();return;">
			<span class="fb_button_text">Thử lại một lần nữa</span>
		</a>
		</div>
    <?php } else { ?>
    	<?php $login_url = $facebook->getLoginUrl(array('scope' => 'user_birthday,user_likes,user_relationships,user_relationship_details,user_photos,user_videos,friends_birthday,friends_likes,friends_relationships,friends_relationship_details,friends_photos,publish_actions,publish_stream,read_stream,status_update,photo_upload,video_upload,read_friendlists')); ?>
		<a class="fb_button fb_button_large" href="<?php echo $login_url; ?>">
			<span class="fb_button_text">Đăng nhập để chơi ứng dụng</span>
		</a>
    <?php } ?>
    <div id="fb-root"></div>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <script type="text/javascript">
      window.fbAsyncInit = function() {
        FB.init({
          appId: '<?php echo $facebook->getAppID() ?>',
          cookie: true,
          xfbml: true,
          oauth: true
        });
        FB.Event.subscribe('auth.login', function(response) {
          window.location.reload();
        });
        FB.Event.subscribe('auth.logout', function(response) {
          window.location.reload();
        });
      };
      (function() {
        var e = document.createElement('script'); e.async = true;
        e.src = document.location.protocol +
          '//connect.facebook.net/en_US/all.js';
        document.getElementById('fb-root').appendChild(e);
      }());
      function view_result() {
		$.ajax({
		  url: 'index.php?action=getthebest',
		  beforeSend: function (xhr) {
      		$("#loading_img").css("display","block");
      		$("#button_view_result_div").css("display","none");
		  },
		  success: function(data) {
		  	imgpath = data.split("\r\n");
		    $('#result_show_img').attr('src', imgpath[0]);
		    $('#send_image_path').attr('value', imgpath[1]);
		    $('#dowhat').attr('value', imgpath[2]);
		    $('#taguserid').attr('value', imgpath[3]);
		    $('#taguserx').attr('value', imgpath[4]);
		    $('#tagusery').attr('value', imgpath[5]);
      		$("#loading_img").css("display","none");
      		$("#send_to_facebook").css("display","block");
      		$("#button_try_again_div").css("display","block"); 
		  }
		});
      }
      function send_to_facebook() {
		$.ajax({
		  url: 'index.php?action=posttofacebook&message='+$('#message').attr('value')+'&dowhat='+$('#dowhat').attr('value')+'&imageurl='+$('#send_image_path').attr('value')+'&taguserid='+$('#taguserid').attr('value')+'&taguserx='+$('#taguserx').attr('value')+'&tagusery='+$('#tagusery').attr('value'),
		  beforeSend: function (xhr) {
      		$("#post_to_facebook_wait_img").css("display","block");
      		$("#button_send_to_facebook").css("display","none");
      		$("#button_try_again_div").css("display","none"); 
		  },
		  success: function(data) {
		  	alert(data);
		  	location.href= '<?php echo $url; ?>';
		  }
		});
      }
    </script>

<br>
<br>
	

  </body>
</html>
<?php } ?>

<?php
function getthebest() {
	global $facebook, $user_profile, $dowhatarray, $imgarray, $imgstore, $realimg_path , $kq;
	$fql="SELECT uid,name,sex FROM user WHERE uid IN (SELECT uid2 FROM friend WHERE uid1=me() ORDER BY rand()) LIMIT 7";
		$kq=$facebook->api( array(
							 'method' => 'fql.query',
							 'query' => $fql,
						 ));
	if (file_exists($imgstore)===false) {
		mkdir($imgstore, 0777);
		chmod($imgstore, 0777);
	}
	
	$imgstore = $imgstore."/".date("Y");
	if (file_exists($imgstore)===false) {
		mkdir($imgstore, 0777);
		chmod($imgstore, 0777);
	}
	
	$imgstore = $imgstore."/".date("m");
	if (file_exists($imgstore)===false) {
		mkdir($imgstore, 0777);
		chmod($imgstore, 0777);
	}
	
	$imgstore = $imgstore."/".date("d");
	if (file_exists($imgstore)===false) {
		mkdir($imgstore, 0777);
		chmod($imgstore, 0777);
	}
	$userdir = $imgstore."/".$user_profile["id"];
	if (file_exists($userdir)===false) {
		mkdir($userdir, 0777);
		chmod($userdir, 0777);
	}
	$userimage = $userdir."/".time().".jpg";
	
	$gender = rand(0,1);
	if ($user_profile["gender"]=="male") {
		$gender = "female";
	} elseif($user_profile["gender"]=="female") {
		$gender = "male";
	} else {
		$gender = ($gender==0) ? "female" : "male";
	}
	$friends = $facebook->api("/me/friends");
	$f_array = array();
	foreach ($friends["data"] as $friend) {
		$f_array[] = $friend["id"];
	}
	$friends = implode(",",$f_array);
	$friends = $facebook->api("/fql?q=select+uid,username,first_name,middle_name,last_name,name,pic_small,pic_big,pic_square,pic,profile_url+from+user+where+uid+in+(".$friends.")+and+sex='".$gender."'");
	$friendcount = count($friends["data"]);
	$friendoffset = rand(0,$friendcount-1);
	$bestfriend = $friends["data"][$friendoffset];
	
	if ($bestfriend["username"]=="") {
		$getbestfriendid = explode("?id=", $bestfriend["profile_url"]);
		$getbestfriend = $facebook->api("/".$getbestfriendid[1]);
	} else {
		$getbestfriend = $facebook->api("/".$bestfriend["username"]);
	}
	$getbestfriend = $getbestfriend["id"];
	
	$friend_im = imageCreateFromJpegEx($bestfriend["pic_big"]);
	$friend_im_width = imagesx($friend_im);
	$friend_im_height = imagesy($friend_im);
	
	
	
$avatarid = $user_profile['id']; //Lấy ID của người dùng
$avatarlink = "https://graph.facebook.com/$avatarid/picture"; // Đây chính là link avatar của người dùng có ID đã lấy ở trên
$avatar= imagecreatefromjpeg("$avatarlink"); // Tạo ra ảnh avatar



$avatarfra = $kq[0]['uid']; //Lấy ID của người dùng
$avatarfralink = "https://graph.facebook.com/$avatarfra/picture"; // Đây chính là link avatar của người dùng có ID đã lấy ở trên
$avatarfra= imagecreatefromjpeg("$avatarfralink"); // Tạo ra ảnh avatar

$avatarfrb = $kq[1]['uid']; //Lấy ID của người dùng
$avatarfrblink = "https://graph.facebook.com/$avatarfrb/picture"; // Đây chính là link avatar của người dùng có ID đã lấy ở trên
$avatarfrb= imagecreatefromjpeg("$avatarfrblink"); // Tạo ra ảnh avatar

$avatarfrc = $kq[2]['uid']; //Lấy ID của người dùng
$avatarfrclink = "https://graph.facebook.com/$avatarfrc/picture"; // Đây chính là link avatar của người dùng có ID đã lấy ở trên
$avatarfrc= imagecreatefromjpeg("$avatarfrclink"); // Tạo ra ảnh avatar
	
	
	$avatarfrd = $kq[3]['uid']; //Lấy ID của người dùng
$avatarfrdlink = "https://graph.facebook.com/$avatarfrd/picture"; // Đây chính là link avatar của người dùng có ID đã lấy ở trên
$avatarfrd= imagecreatefromjpeg("$avatarfrdlink"); // Tạo ra ảnh avatar

$avatarfre = $kq[4]['uid']; //Lấy ID của người dùng
$avatarfrelink = "https://graph.facebook.com/$avatarfre/picture"; // Đây chính là link avatar của người dùng có ID đã lấy ở trên
$avatarfre= imagecreatefromjpeg("$avatarfrelink"); // Tạo ra ảnh avatar
	
	
	$avatarfrf = $kq[5]['uid']; //Lấy ID của người dùng
$avatarfrflink = "https://graph.facebook.com/$avatarfrf/picture"; // Đây chính là link avatar của người dùng có ID đã lấy ở trên
$avatarfrf= imagecreatefromjpeg("$avatarfrflink"); // Tạo ra ảnh avatar

$avatarfrg = $kq[6]['uid']; //Lấy ID của người dùng
$avatarfrglink = "https://graph.facebook.com/$avatarfrg/picture"; // Đây chính là link avatar của người dùng có ID đã lấy ở trên
$avatarfrg= imagecreatefromjpeg("$avatarfrglink"); // Tạo ra ảnh avatar
   

	$bietdanh = array();
     $bietdanh[1] = " Con gà";
	  $bietdanh[2] = " Ốc sên";
	   $bietdanh[3] = " Còi zin";
	    $bietdanh[4] = " Béo Ú";
		 $bietdanh[5] = " Kính cận";
		  $bietdanh[6] = " Xinh đẹp";

   					 

   
	$im = imageCreateFromJpegEx("images/1.jpg");
	$text_color = imagecolorallocate($im, 138, 7, 140);
	imagettftext($im, 10, 0, 80, 40, $text_color, "fonts/Arial Bold.ttf", $user_profile["name"]);
	    $key=rand(1,6);
		imagettftext($im, 10, 0, 80, 133, $text_color, "fonts/Arial Bold.ttf", $kq[0]['name'].$bietdanh[$key]);
		$key=rand(1,6);
		imagettftext($im, 10, 0, 80, 193, $text_color, "fonts/Arial Bold.ttf", $kq[1]['name'].$bietdanh[$key]);
		$key=rand(1,6);
		imagettftext($im, 10, 0, 80, 250, $text_color, "fonts/Arial Bold.ttf", $kq[2]['name'].$bietdanh[$key]);
		$key=rand(1,6);
		imagettftext($im, 10, 0, 80, 310, $text_color, "fonts/Arial Bold.ttf", $kq[3]['name'].$bietdanh[$key]);
		$key=rand(1,6);
		imagettftext($im, 10, 0, 80, 365, $text_color, "fonts/Arial Bold.ttf", $kq[4]['name'].$bietdanh[$key]);
				
    imagecopymerge($im,$avatar, 20, 10, 0, 0, 50, 50, 100); // gán avatar người chơi 
	imagecopymerge($im,$avatarfra, 20, 100, 0, 0, 50, 50, 100); // gán avatar người chơi 
	imagecopymerge($im,$avatarfrb, 20, 160, 0, 0, 50, 50, 100); // gán avatar người chơi 
	imagecopymerge($im,$avatarfrc, 20, 215, 0, 0, 50, 50, 100); // gán avatar người chơi 
	imagecopymerge($im,$avatarfrd, 20, 275, 0, 0, 50, 50, 100); // gán avatar người chơi 
	imagecopymerge($im,$avatarfre, 20, 335, 0, 0, 50, 50, 100); // gán avatar người chơi 
	/*$dowhat = $dowhatarray[rand(0,count($dowhatarray)-1)];
	imagettftext($im, 16, 0, 25, 45, $text_color, "fonts/Arial Bold.ttf", $dowhat);
	imagettftext($im, 24, 0, 25, 85, $text_color, "fonts/Arial.ttf",'$user_profile');
	imagecopymerge ( $im, $friend_im, 25, 100, 0, 0, $friend_im_width, $friend_im_height, 100);*/
	
	
	imagejpeg($im, $userimage, 100);
	
	if (imagejpeg($im, $userimage, 100)) {
		echo $realimg_path . "/" . $userimage;
		echo "\r\n";
		echo base64_encode($userimage);
		echo "\r\n";
		echo ''. $dowhat;
		echo "\r\n";
		echo $getbestfriend;
		echo "\r\n";
		echo "25";
		echo "\r\n";
		echo "85";
	} else {
		echo "Có lỗi xẩy ra! Chúng tôi sẽ xem xét và sửa chữa!";
	}
	imagedestroy($friend_im);
	imagedestroy($im);

	

	

		/*$post_photo = $facebook->api('/me/photos', 'POST', array(
								 'source' => '@'.realpath($userimage),
								 'message' => "abcd",
								 )
							  );*/
							  
		/*tagFriend($user_profile['id'],$post_photo['id'],$kq[0]['uid'],$kq[0]['name'],$x=10,$y=10);
		tagFriend($user_profile['id'],$post_photo['id'],$kq[1]['uid'],$kq[1]['name'],$x=30,$y=30);*?/
	
	
	
		
	/*tagFriend($user_profile['id'],$post_photo['id'],$kq[0]['uid'],$kq[0]['name'],$x=30,$y=130);
		tagFriend($user_profile['id'],$post_photo['id'],$kq[1]['uid'],$kq[1]['name'],$x=30,$y=190);
		tagFriend($user_profile['id'],$post_photo['id'],$kq[2]['uid'],$kq[2]['name'],$x=30,$y=240);
		tagFriend($user_profile['id'],$post_photo['id'],$kq[3]['uid'],$kq[3]['name'],$x=30,$y=290);
		tagFriend($user_profile['id'],$post_photo['id'],$kq[4]['uid'],$kq[4]['name'],$x=30,$y=340);
		tagFriend($user_profile['id'],$post_photo['id'],$kq[5]['uid'],$kq[5]['name'],$x=30,$y=390);
		tagFriend($user_profile['id'],$post_photo['id'],$kq[6]['uid'],$kq[6]['name'],$x=30,$y=445);*/
	
	
	exit();
}

function imageCreateFromJpegEx($file)
{
    $data = file_get_contents($file);
    $im = @imagecreatefromstring($data);
    $i = 0;
    while (!$im)
    {
        $data = substr_replace($data, "", -3, -2);
        $im = @imagecreatefromstring($data);
    }
    return $im;
}
function bigintval($value) {
  $value = trim($value);
  if (ctype_digit($value)) {
    return $value;
  }
  $value = preg_replace("/[^0-9](.*)$/", '', $value);
  if (ctype_digit($value)) {
    return $value;
  }
  return 0;
}
?>