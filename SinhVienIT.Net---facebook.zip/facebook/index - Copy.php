<?php

$dowhatarray = array();
$dowhatarray[] = " HÔN BẠN LÀ";
$dowhatarray[] = " ÔM BẠN LÀ";
$dowhatarray[] = " ĐÁ ĐÍT BẠN LÀ";
$dowhatarray[] = " SỜ MŨI BẠN LÀ";
$dowhatarray[] = " SỜ MÔNG BẠN LÀ";
$dowhatarray[] = " VÉO TAI BẠN LÀ";
$dowhatarray[] = " TÚM TÓC BẠN LÀ";

$imgarray = array();
$imgarray[] = "0.jpg";
$imgarray[] = "1.jpg";
$imgarray[] = "2.jpg";
$imgarray[] = "3.jpg";
$imgarray[] = "4.jpg";
$imgarray[] = "5.jpg";
$imgarray[] = "6.jpg";

$imgstore = "user_images";
$realimg_path = "http://hoithovanucuoi.com/apps";

$url = "http://goo.gl/GKYvC";

require 'src/facebook.php';

$action = (@$_REQUEST["action"]) ? $_REQUEST["action"] : "";

$facebook = new Facebook(array(
  'appId'  => '339126919459184',
  'secret' => 'e67d2e121af6066f157488fb18e94591',
));

// See if there is a user from a cookie
$user = $facebook->getUser();

if ($user) {
  try {
    // Proceed knowing you have a logged in user who's authenticated.
    $user_profile = $facebook->api('/me');
  } catch (FacebookApiException $e) {
    echo '<pre>'.htmlspecialchars(print_r($e, true)).'</pre>';
    $user = null;
  }
}
if ($action=='getthebest') {
	if ($user) {
		getthebest();
	} else {
    	$login_url = $facebook->getLoginUrl(array('scope' => 'user_birthday,user_likes,user_relationships,user_relationship_details,user_photos,user_videos,friends_birthday,friends_likes,friends_relationships,friends_relationship_details,friends_photos,publish_actions,publish_stream,read_stream,status_update,photo_upload,video_upload,read_friendlists'));
    	?>
		<a class="fb_button fb_button_large" href="<?php echo $login_url; ?>">
			<span class="fb_button_text">Đăng nhập để sử dụng ứng dụng</span>
		</a>
		<?php
	}
} elseif($action=="posttofacebook") {
	if ($user) {
		$imageurl = (@$_REQUEST["imageurl"]) ? $_REQUEST["imageurl"] : "";
		$imageurl = base64_decode($imageurl);
		$dowhat = (@$_REQUEST["dowhat"]) ? $_REQUEST["dowhat"] : "";
		$message = (@$_REQUEST["message"]) ? $_REQUEST["message"] : "";
		$taguserid = (@$_REQUEST["taguserid"]) ? $_REQUEST["taguserid"] : "";
		$taguserx = (@$_REQUEST["taguserx"]) ? $_REQUEST["taguserx"] : "";
		$tagusery = (@$_REQUEST["tagusery"]) ? $_REQUEST["tagusery"] : "";
		
		$tags = array();
		$tags[] = array('tag_uid' => $taguserid, 'x' => intval($taguserx), 'y' => intval($tagusery));
		$tags = json_encode($tags);
		
		$facebook->setFileUploadSupport(true);
		//Create an album
		$album_details = array(
        'message'=> 'Người tình Valentine',
        'name'=> 'Người tình Valentine'
        );
        $create_album = $facebook->api('/me/albums', 'post', $album_details);
        $album_uid = $create_album['id'];
		//Upload a photo to album of ID...
		$photo_details = array(
    		'message' => $message ."\r\n". $dowhat . "\r\nXem kết quả tại: " . $url,
    		'tags' => $tags
		);
		$file=$imageurl; //Example image file
		$photo_details['image'] = '@' . realpath($file);
		$upload_photo = $facebook->api('/'.$album_uid.'/photos', 'post', $photo_details);
		echo "Kết quả đã được gửi lên Facebook, cảm ơn bạn đã sử dụng ứng dụng này!";
		@unlink($imageurl);
	} else {
    	$login_url = $facebook->getLoginUrl(array('scope' => 'user_birthday,user_likes,user_relationships,user_relationship_details,user_photos,user_videos,friends_birthday,friends_likes,friends_relationships,friends_relationship_details,friends_photos,publish_actions,publish_stream,read_stream,status_update,photo_upload,video_upload,read_friendlists'));
    	?>
		<a class="fb_button fb_button_large" href="<?php echo $login_url; ?>">
			<span class="fb_button_text">Đăng nhập để sử dụng ứng dụng</span>
		</a>
		<?php
	}
} else {
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://www.facebook.com/2008/fbml"><head><title>Hơi thở và nụ cười</title><style type="text/css">
<!--
body,td,th {
	font-family: Times New Roman, Times, serif;
}
-->
</style><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
  <body style="text-align:center;">
    <?php if ($user) { ?>
    	<div class="result_show">
    		<img src="images/blank.gif" id="result_show_img" />
    	</div>
    	<div id="loading_img" style="display:none;">
    		<img src="images/loading-long.gif" /><br />
    		Vui lòng chờ trong giây lát! Chúng tôi đang tính toán kết quả cho bạn!
    	</div>
    	<div id="button_view_result_div">
		<a id="button_view_result" class="fb_button fb_button_large" href="#" onClick="view_result();return;">
			<span class="fb_button_text">Xem kết quả</span>
		</a>
		<br />
		<br />
		</div>
		<div id="send_to_facebook" style="display:none;">
		Viết cảm nhận của bạn:<br />
		<input type="textbox" name="message" id="message" size="30" />
		<input id="send_image_path" type="hidden" name="imgpath" value="" />
		<input id="dowhat" type="hidden" name="do_what" value="" />
		<input id="taguserid" type="hidden" name="taguserid" value="" />
		<input id="taguserx" type="hidden" name="taguserx" value="" />
		<input id="tagusery" type="hidden" name="tagusery" value="" />
		<br />
		<a id="button_send_to_facebook" class="fb_button fb_button_large" href="#" onClick="send_to_facebook();return;">
			<span class="fb_button_text">Gửi lên Facebook</span>
		</a>
		</div>
    	<div id="post_to_facebook_wait_img" style="display:none;">
    		<br />
    		<br />
    		<img src="images/loading-long.gif" /><br />
    		Vui lòng chờ trong giây lát! Chúng tôi đang đưa kết quả của bạn lên Facebook!
    	</div>
    	<div id="button_try_again_div" style="display:none;">
		<br />
		<br />
		<a id="button_try_again" class="fb_button fb_button_large" href="#" onClick="location.reload();return;">
			<span class="fb_button_text">Thử lại một lần nữa</span>
		</a>
		</div>
    <?php } else { ?>
    	<?php $login_url = $facebook->getLoginUrl(array('scope' => 'user_birthday,user_likes,user_relationships,user_relationship_details,user_photos,user_videos,friends_birthday,friends_likes,friends_relationships,friends_relationship_details,friends_photos,publish_actions,publish_stream,read_stream,status_update,photo_upload,video_upload,read_friendlists')); ?>
		<a class="fb_button fb_button_large" href="<?php echo $login_url; ?>">
			<span class="fb_button_text">Đăng nhập để sử dụng ứng dụng</span>
		</a>
    <?php } ?>
    <div id="fb-root"></div>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <script type="text/javascript">
      window.fbAsyncInit = function() {
        FB.init({
          appId: '<?php echo $facebook->getAppID() ?>',
          cookie: true,
          xfbml: true,
          oauth: true
        });
        FB.Event.subscribe('auth.login', function(response) {
          window.location.reload();
        });
        FB.Event.subscribe('auth.logout', function(response) {
          window.location.reload();
        });
      };
      (function() {
        var e = document.createElement('script'); e.async = true;
        e.src = document.location.protocol +
          '//connect.facebook.net/en_US/all.js';
        document.getElementById('fb-root').appendChild(e);
      }());
      function view_result() {
		$.ajax({
		  url: 'index.php?action=getthebest',
		  beforeSend: function (xhr) {
      		$("#loading_img").css("display","block");
      		$("#button_view_result_div").css("display","none");
		  },
		  success: function(data) {
		  	imgpath = data.split("\r\n");
		    $('#result_show_img').attr('src', imgpath[0]);
		    $('#send_image_path').attr('value', imgpath[1]);
		    $('#dowhat').attr('value', imgpath[2]);
		    $('#taguserid').attr('value', imgpath[3]);
		    $('#taguserx').attr('value', imgpath[4]);
		    $('#tagusery').attr('value', imgpath[5]);
      		$("#loading_img").css("display","none");
      		$("#send_to_facebook").css("display","block");
      		$("#button_try_again_div").css("display","block"); 
		  }
		});
      }
      function send_to_facebook() {
		$.ajax({
		  url: 'index.php?action=posttofacebook&message='+$('#message').attr('value')+'&dowhat='+$('#dowhat').attr('value')+'&imageurl='+$('#send_image_path').attr('value')+'&taguserid='+$('#taguserid').attr('value')+'&taguserx='+$('#taguserx').attr('value')+'&tagusery='+$('#tagusery').attr('value'),
		  beforeSend: function (xhr) {
      		$("#post_to_facebook_wait_img").css("display","block");
      		$("#button_send_to_facebook").css("display","none");
      		$("#button_try_again_div").css("display","none"); 
		  },
		  success: function(data) {
		  	alert(data);
		  	location.href= '<?php echo $url; ?>';
		  }
		});
      }
    </script>
  </body>
</html>
<?php } ?>

<?php
function getthebest() {
	global $facebook, $user_profile, $dowhatarray, $imgarray, $imgstore, $realimg_path;
	if (file_exists($imgstore)===false) {
		mkdir($imgstore, 0777);
		chmod($imgstore, 0777);
	}
	
	$imgstore = $imgstore."/".date("Y");
	if (file_exists($imgstore)===false) {
		mkdir($imgstore, 0777);
		chmod($imgstore, 0777);
	}
	
	$imgstore = $imgstore."/".date("m");
	if (file_exists($imgstore)===false) {
		mkdir($imgstore, 0777);
		chmod($imgstore, 0777);
	}
	
	$imgstore = $imgstore."/".date("d");
	if (file_exists($imgstore)===false) {
		mkdir($imgstore, 0777);
		chmod($imgstore, 0777);
	}
	$userdir = $imgstore."/".$user_profile["id"];
	if (file_exists($userdir)===false) {
		mkdir($userdir, 0777);
		chmod($userdir, 0777);
	}
	$userimage = $userdir."/".time().".jpg";
	
	$gender = rand(0,1);
	if ($user_profile["gender"]=="male") {
		$gender = "female";
	} elseif($user_profile["gender"]=="female") {
		$gender = "male";
	} else {
		$gender = ($gender==0) ? "female" : "male";
	}
	$friends = $facebook->api("/me/friends");
	$f_array = array();
	foreach ($friends["data"] as $friend) {
		$f_array[] = $friend["id"];
	}
	$friends = implode(",",$f_array);
	$friends = $facebook->api("/fql?q=select+uid,username,first_name,middle_name,last_name,name,pic_small,pic_big,pic_square,pic,profile_url+from+user+where+uid+in+(".$friends.")+and+sex='".$gender."'");
	$friendcount = count($friends["data"]);
	$friendoffset = rand(0,$friendcount-1);
	$bestfriend = $friends["data"][$friendoffset];
	
	if ($bestfriend["username"]=="") {
		$getbestfriendid = explode("?id=", $bestfriend["profile_url"]);
		$getbestfriend = $facebook->api("/".$getbestfriendid[1]);
	} else {
		$getbestfriend = $facebook->api("/".$bestfriend["username"]);
	}
	$getbestfriend = $getbestfriend["id"];
	
	$friend_im = imageCreateFromJpegEx($bestfriend["pic_big"]);
	$friend_im_width = imagesx($friend_im);
	$friend_im_height = imagesy($friend_im);
	
	$im = imageCreateFromJpegEx("images/".$imgarray[rand(0,count($imgarray)-1)]);
	$text_color = imagecolorallocate($im, 255, 255, 255);
	$dowhat = $dowhatarray[rand(0,count($dowhatarray)-1)];
	imagettftext($im, 16, 0, 25, 20, $text_color, "fonts/Arial Bold.ttf", 'Người đang muốn');
	imagettftext($im, 16, 0, 25, 45, $text_color, "fonts/Arial Bold.ttf", $dowhat);
	imagettftext($im, 24, 0, 25, 85, $text_color, "fonts/Arial.ttf", $bestfriend["name"]);
	imagecopymerge ( $im, $friend_im, 25, 100, 0, 0, $friend_im_width, $friend_im_height, 100);
	if (imagejpeg($im, $userimage, 100)) {
		echo $realimg_path . "/" . $userimage;
		echo "\r\n";
		echo base64_encode($userimage);
		echo "\r\n";
		echo 'Người đang muốn '. $dowhat;
		echo "\r\n";
		echo $getbestfriend;
		echo "\r\n";
		echo "25";
		echo "\r\n";
		echo "85";
	} else {
		echo "Có lỗi xẩy ra! Chúng tôi sẽ xem xét và sửa chữa!";
	}
	imagedestroy($friend_im);
	imagedestroy($im);
	exit();
}

function imageCreateFromJpegEx($file)
{
    $data = file_get_contents($file);
    $im = @imagecreatefromstring($data);
    $i = 0;
    while (!$im)
    {
        $data = substr_replace($data, "", -3, -2);
        $im = @imagecreatefromstring($data);
    }
    return $im;
}
function bigintval($value) {
  $value = trim($value);
  if (ctype_digit($value)) {
    return $value;
  }
  $value = preg_replace("/[^0-9](.*)$/", '', $value);
  if (ctype_digit($value)) {
    return $value;
  }
  return 0;
}
?>