<?php
function NgayThangNam($str)
{
$str=strtolower($str);
$str=str_replace("sunday","Ch? nh?t",$str);
$str=str_replace("monday","Th? hai",$str);
$str=str_replace("tuesday","Th? ba",$str);
$str=str_replace("wednesday","Th? tu",$str);
$str=str_replace("thursday","Th? nam",$str);
$str=str_replace("friday","Th? s�u",$str);
$str=str_replace("saturday","Th? b?y",$str);
$s1=strpos($str,", ",0)+strlen(", ");
$s2=strpos($str," ",$s1);
$Thang=substr($str,$s1,$s2-$s1);
$str=str_replace(", ".$Thang,",Ng�y",$str);
$str=str_replace(", "," th�ng $Thang,Nam ",$str);
$str=str_replace(",",", ",$str);

$str=str_replace("january","1",$str);
$str=str_replace("february","2",$str);
$str=str_replace("march","3",$str);
$str=str_replace("aprill","4",$str);
$str=str_replace("may","5",$str);
$str=str_replace("june","6",$str);
$str=str_replace("july","7",$str);
$str=str_replace("august","8",$str);
$str=str_replace("september","9",$str);
$str=str_replace("october","10",$str);
$str=str_replace("november","11",$str);
$str=str_replace("december","12",$str);
return $str;
}
$BMI=round((50)/(1.70*1.70));
$source=file_get_contents( "http://deathclock.com/dw.cfm?Day=17&Month=8&Year=1993&Sex=male&Mode=normal&bmi=$BMI&smoker=0");
$s1=strpos($source,"<script language=\"javascript\">",0);
$s2=strpos($source,"</script>",$s1)+strlen("</script>");
echo substr($source,$s1,$s2-$s1);
$s1=strpos($source,"<!-- Day of death -->",0)+strlen("<!-- Day of death -->");
$s1=strpos($source,"<b>",$s1)+strlen("<b>");
$s2=strpos($source,"<",$s1);
	$Ngay=substr($source,$s1,$s2-$s1);
echo $ngay;
?>